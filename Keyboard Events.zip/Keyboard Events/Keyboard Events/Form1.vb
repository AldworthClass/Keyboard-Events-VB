﻿Public Class frmKeyEvents
    Private Sub frmKeyEvents_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Up Then
            lblKeyInfo.Text = "You are pressing Up"
            imgBall.Top -= 2
        ElseIf e.KeyCode = Keys.Down Then
            lblKeyInfo.Text = "You are pressing Down"
            imgBall.Top += 2
        ElseIf e.KeyCode = Keys.Left Then
            lblKeyInfo.Text = "You are pressing Left"
            imgBall.Left -= 2
        ElseIf e.KeyCode = Keys.Right Then
            lblKeyInfo.Text = "You are pressing Right"
            imgBall.Left += 2
        ElseIf e.KeyCode = Keys.R Then
            Me.BackColor = Color.Red
        ElseIf e.KeyCode = Keys.B Then
            Me.BackColor = Color.Blue
        ElseIf e.KeyCode = Keys.G Then
            Me.BackColor = Color.Green
        End If
    End Sub

    Private Sub frmKeyEvents_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Up Then
            lblKeyInfo.Text = "You released Up"
        ElseIf e.KeyCode = Keys.Down Then
            lblKeyInfo.Text = "You released Down"
        ElseIf e.KeyCode = Keys.Left Then
            lblKeyInfo.Text = "You released Left"
        ElseIf e.KeyCode = Keys.Right Then
            lblKeyInfo.Text = "You released Right"
        ElseIf e.KeyCode = Keys.R Then
            Me.BackColor = DefaultBackColor
        ElseIf e.KeyCode = Keys.B Then
            Me.BackColor = DefaultBackColor
        ElseIf e.KeyCode = Keys.G Then
            Me.BackColor = DefaultBackColor
        End If
    End Sub
End Class
